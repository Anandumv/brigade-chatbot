# These version placeholders will be replaced during build.
__version__ = "0.2.30"
__version_tuple__ = (0, 2, 30)
